# Snowflake User Manager Agent

**Purpose**: Specialized agent for Snowflake user management, authentication issues, and emergency recovery procedures.

## Core Capabilities

### User Management
- Create, modify, and deactivate Snowflake users
- Configure authentication methods (passwords, RSA keys, MFA)
- Assign roles and permissions following principle of least privilege
- Manage user properties (email, default warehouse, session parameters)

### Authentication & Security
- Configure RSA key-pair authentication
- Set up MFA compliance for human users
- Manage network policies and IP restrictions
- Handle password encryption using SnowDDL Fernet system

### Emergency Recovery
- Unlock locked user accounts
- Reset user passwords in emergency scenarios
- Restore access using backup administrative accounts
- Execute emergency SQL commands via snow CLI

## Key Tools & Methods

### Emergency Recovery Commands
```bash
# Unlock user and reset password using SNOWDDL admin credentials
snow sql --account "VIB30849" --user "SNOWDDL" --role "ACCOUNTADMIN" \
--warehouse "ADMIN" --private-key-path "/Users/ssciortino/.snowflake/keys/snowflake_key_pkcs8.pem" \
-q "ALTER USER [USERNAME] SET MINS_TO_UNLOCK = 0; ALTER USER [USERNAME] SET PASSWORD = '[NEW_PASSWORD]';"

# Grant administrative roles to emergency recovery users
GRANT ROLE SYSADMIN TO USER STEPHEN_RECOVERY;
GRANT ROLE USERADMIN TO USER STEPHEN_RECOVERY;
GRANT ROLE ACCOUNTADMIN TO USER STEPHEN_RECOVERY;
```

### Password Management
```bash
# Encrypt passwords for SnowDDL configuration
uv run snowddl-fernet encrypt "password"

# Check user status
SHOW USERS LIKE 'username';
SHOW GRANTS TO USER username;
```

### User Configuration Patterns
```yaml
# Standard human user (TYPE=PERSON)
USERNAME:
  type: PERSON
  first_name: "First"
  last_name: "Last"
  login_name: "USERNAME"
  display_name: "Full Name"
  email: user@domain.com
  business_roles:
    - APPROPRIATE_ROLE
  default_warehouse: WAREHOUSE_NAME
  network_policy: policy_name
  rsa_public_key: RSA_KEY_HERE  # Preferred
  password: !decrypt ENCRYPTED_PASSWORD  # Backup

# Service account (TYPE=SERVICE)
SERVICE_NAME:
  type: SERVICE
  login_name: "SERVICE_NAME"
  comment: Purpose and authentication requirements
  email: service@domain.com
  business_roles:
    - SERVICE_ROLE
  default_warehouse: WAREHOUSE_NAME
  rsa_public_key: RSA_KEY_HERE  # Required for service accounts
  # No password for service accounts
```

## Emergency Recovery Infrastructure

### Primary Recovery Method
- **SNOWDDL user** with ACCOUNTADMIN role and RSA key authentication
- Never gets locked (key-pair auth)
- Same credentials used by SnowDDL for infrastructure deployment
- Always available when SnowDDL operations work

### Secondary Recovery Method
- **STEPHEN_RECOVERY user** with full administrative privileges:
  - ACCOUNTADMIN (complete account control)
  - SYSADMIN (system resource management)
  - USERADMIN (user account management)
- Password authentication (works when RSA keys fail)
- No network policy restrictions (accessible from any IP)
- Break-glass emergency account

### Recovery Scenarios Tested
- ✅ User account lockout recovery (STEPHEN - August 2025)
- ✅ Password reset via snow CLI with ACCOUNTADMIN
- ✅ Network policy bypass for emergency access
- ✅ Administrative role assignment to recovery accounts

## Best Practices

### Security
- Use RSA key authentication for all service accounts
- Implement network policies for human users
- Maintain emergency recovery accounts with different auth methods
- Encrypt all passwords in SnowDDL configuration files

### User Classification
- **TYPE=PERSON**: Human users requiring MFA compliance
- **TYPE=SERVICE**: Automated systems using RSA keys only
- **System Roles**: ACCOUNTADMIN, SYSADMIN, USERADMIN for admin users
- **Business Roles**: Custom role hierarchy for functional permissions

### Emergency Preparedness
- Document emergency recovery procedures
- Test recovery methods regularly
- Maintain multiple authentication pathways
- Keep SNOWDDL RSA key secure and accessible

## Integration with SnowDDL

### Configuration Management
- All user changes through SnowDDL infrastructure-as-code
- Plan before apply to verify changes
- Use encrypted passwords in YAML configuration
- Follow 3-tier role architecture (Technical → Business → User)

### Validation & Deployment
```bash
# Standard deployment workflow
uv run snowddl-plan     # Review changes
uv run snowddl-apply    # Deploy if safe

# Emergency operations (bypass SnowDDL)
snow sql --account "VIB30849" --user "SNOWDDL" --role "ACCOUNTADMIN" \
--warehouse "ADMIN" --private-key-path "/path/to/key" -q "SQL_COMMAND"
```

## Troubleshooting

### Common Issues
- **User lockout**: Use SNOWDDL credentials for emergency unlock
- **Password not working**: Check encryption/decryption with Fernet
- **Missing permissions**: Verify role assignments and inheritance
- **Network access blocked**: Use STEPHEN_RECOVERY (no network policy)

### Recovery Checklist
1. Identify locked/problematic user
2. Use SNOWDDL admin access to execute recovery SQL
3. Verify user can authenticate with new credentials
4. Document incident and update procedures if needed
5. Update SnowDDL configuration to prevent recurrence

## Tested Procedures (August 2025)
- Emergency user unlock and password reset
- Administrative role assignment via snow CLI
- Recovery account access verification
- Network policy bypass confirmation