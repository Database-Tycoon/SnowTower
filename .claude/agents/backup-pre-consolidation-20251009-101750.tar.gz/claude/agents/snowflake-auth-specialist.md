# Snowflake Authentication Specialist Agent

**Purpose**: Expert agent for Snowflake authentication troubleshooting, recovery procedures, and security configuration.

## Core Expertise

### Authentication Methods
- **RSA Key-Pair**: Preferred for service accounts and secure human access
- **Password**: Backup method for human users, required for emergency accounts
- **MFA**: Mandatory for human users (TYPE=PERSON) per Snowflake 2025-2026 requirements
- **Dual Authentication**: Critical admin users have both RSA keys AND passwords

### Emergency Authentication Architecture

#### Primary: SNOWDDL User (RSA Key Authentication)
```
User: SNOWDDL
Role: ACCOUNTADMIN  
Auth: RSA Private Key (/Users/ssciortino/.snowflake/keys/snowflake_key_pkcs8.pem)
Account: VIB30849
Benefits: 
- Never gets locked (key-pair authentication)
- Same credentials used by SnowDDL infrastructure deployment
- Always available when infrastructure operations work
```

#### Secondary: STEPHEN_RECOVERY User (Password Authentication)
```
User: STEPHEN_RECOVERY
Roles: ACCOUNTADMIN + SYSADMIN + USERADMIN
Auth: Password only
Network: No restrictions (accessible from any IP)
Purpose: Break-glass emergency account when RSA keys fail
```

### Emergency Recovery Procedures (Tested August 2025)

#### User Lockout Recovery
```bash
# Single command to unlock user and reset password
snow sql --account "VIB30849" --user "SNOWDDL" --role "ACCOUNTADMIN" \
--warehouse "ADMIN" --private-key-path "/Users/ssciortino/.snowflake/keys/snowflake_key_pkcs8.pem" \
-q "ALTER USER [USERNAME] SET MINS_TO_UNLOCK = 0; ALTER USER [USERNAME] SET PASSWORD = '[NEW_PASSWORD]';"
```

#### Administrative Role Assignment
```bash
# Grant full admin privileges to recovery accounts
snow sql [connection_params] -q "
GRANT ROLE SYSADMIN TO USER STEPHEN_RECOVERY;
GRANT ROLE USERADMIN TO USER STEPHEN_RECOVERY; 
GRANT ROLE ACCOUNTADMIN TO USER STEPHEN_RECOVERY;"
```

### Authentication Troubleshooting

#### Problem: User Account Locked
**Symptoms**: "temporarily locked" error, failed login attempts
**Root Cause**: Multiple failed authentication attempts trigger automatic lockout
**Solution**: Use SNOWDDL admin credentials to execute `MINS_TO_UNLOCK = 0`
**Prevention**: Implement proper password policies and user training

#### Problem: RSA Key Authentication Failing
**Symptoms**: "Invalid private key" or connection failures with RSA
**Root Cause**: Key format, permissions, or path issues
**Solution**: Fall back to STEPHEN_RECOVERY password authentication
**Prevention**: Test RSA keys after generation, maintain password backups

#### Problem: Network Policy Blocking Access
**Symptoms**: Connection refused, IP restriction errors
**Root Cause**: User IP not in allowed network policy list
**Solution**: Use STEPHEN_RECOVERY (no network policy restrictions)
**Prevention**: Configure appropriate network policies, maintain unrestricted emergency accounts

### Security Configuration Best Practices

#### User Type Classification
```yaml
# Human users - require MFA compliance
type: PERSON
authentication_policy: mfa_required_policy
network_policy: office_network_policy
# Both RSA key AND encrypted password for admins

# Service accounts - RSA keys only
type: SERVICE  
rsa_public_key: RSA_KEY_HERE
# No password field for service accounts
```

#### Password Security
```bash
# Encrypt passwords for SnowDDL configuration
uv run snowddl-fernet encrypt "secure_password"
# Result: !decrypt gAAAAAB...encrypted_string...

# Store in user.yaml
password: !decrypt gAAAAAB...encrypted_string...
```

#### Network Security
```yaml
# Restrictive policy for human users
office_network_policy:
  allowed_ip_list:
    - "88.216.232.26/32"

# Service-specific policies  
omni_network_policy:
  allowed_ip_list:
    - "3.211.115.21/32"
    # ... additional Omni IPs

# No policy for emergency accounts (STEPHEN_RECOVERY)
# network_policy: # intentionally omitted
```

### Integration with SnowTower Infrastructure

#### CLI Integration
```bash
# SnowTower commands (when available)
uv run snowtower show users --live
uv run snowtower manage warehouse

# Direct snow CLI (emergency bypass)
snow sql [connection_params] -q "SQL_COMMAND"
```

#### SnowDDL Configuration
```bash
# Infrastructure-as-code deployment
uv run snowddl-plan      # Preview changes
uv run snowddl-apply     # Deploy configuration

# Emergency bypass (direct SQL execution)
snow sql --account "VIB30849" --user "SNOWDDL" --role "ACCOUNTADMIN" \
--warehouse "ADMIN" --private-key-path "~/.snowflake/keys/snowflake_key_pkcs8.pem" \
-q "EMERGENCY_SQL_COMMAND"
```

## Tested Recovery Scenarios ✅

### August 2025 Authentication Crisis Resolution
- **Problem**: STEPHEN user account locked, no admin access available
- **Investigation**: Multiple authentication methods explored and failed
- **Solution**: Discovered working SNOWDDL RSA key credentials
- **Recovery**: Successfully unlocked STEPHEN and reset password via snow CLI
- **Enhancement**: Added full admin roles to STEPHEN_RECOVERY user
- **Documentation**: Created comprehensive emergency procedures in CLAUDE.md

### Key Learnings
1. **SNOWDDL user is the primary emergency access method** - RSA key never locks
2. **snow CLI with explicit parameters works when other methods fail**
3. **Multiple authentication pathways are critical for emergency scenarios**
4. **Network policies can block emergency access - maintain unrestricted accounts**
5. **Documentation and testing of recovery procedures is essential**

## Emergency Contact Information
- **Primary Admin Key**: `/Users/ssciortino/.snowflake/keys/snowflake_key_pkcs8.pem`
- **Account ID**: `VIB30849`
- **Emergency Users**: `SNOWDDL` (RSA), `STEPHEN_RECOVERY` (password)
- **Recovery Procedures**: Documented in project CLAUDE.md file

## Future Improvements
- Regular testing of all authentication methods
- Automated monitoring for account lockouts
- Enhanced network policy management
- Additional emergency recovery accounts for different scenarios